package controller;

public class AlbumController {
	//yay
	
	//criar album
	//editar album
	//remover album
	//buscar album
	//listar albuns
	//listar album buscado
	//getalbum
	//adicionar album na livraria
}
