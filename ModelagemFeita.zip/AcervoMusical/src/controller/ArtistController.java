package controller;

public class ArtistController {
	//nothing to see here folks, move ahead...
	
	//criar artista
	//editar artista
	//remover artista
	//buscar artista
	//listar artistas
	//listar artista buscado
	//getartista
	//adicionar artista em X album
}
