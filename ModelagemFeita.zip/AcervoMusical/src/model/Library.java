package model;

public class Library {
	//when the LibraryController is ready, this will be implemented.
}
