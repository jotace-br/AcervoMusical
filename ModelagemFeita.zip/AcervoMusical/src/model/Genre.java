package model;

public enum Genre {
	ROCK("rock"),
	POP("pop"),
	UNKNOWN("desconhecido");

	Genre(String string) {
		// TODO Auto-generated constructor stub
	}
	
	
}
