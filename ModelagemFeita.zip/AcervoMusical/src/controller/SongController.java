package controller;

public class SongController {
	//sonic boom!
	
	//criar musica
	//editar musica
	//remover musica
	//buscar musica
	//listar musica
	//listar musica buscada
	//getmusica
	//adicionar musica em X album
}
