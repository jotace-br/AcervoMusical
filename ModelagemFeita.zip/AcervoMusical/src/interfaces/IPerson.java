package interfaces;

public interface IPerson {
	String getName();
	void setName(String name);
	
	public int getAge();
	void setAge(int age);
}
